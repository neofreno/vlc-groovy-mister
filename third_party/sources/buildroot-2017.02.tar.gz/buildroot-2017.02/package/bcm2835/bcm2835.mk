################################################################################
#
# bcm2835
#
################################################################################

BCM2835_VERSION = 1.48
BCM2835_SITE = http://www.airspayce.com/mikem/bcm2835
BCM2835_LICENSE = GPLv2
BCM2835_LICENSE_FILES = COPYING
BCM2835_INSTALL_STAGING = YES

$(eval $(autotools-package))
